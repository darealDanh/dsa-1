/*
 *   Copyright (c) 2012, Michael Lehn, Klaus Pototzky
 *
 *   All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *   1) Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2) Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *   3) Neither the name of the FLENS development group nor the names of
 *      its contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef CXXLAPACK_INTERFACE_LAED7_TCC
#define CXXLAPACK_INTERFACE_LAED7_TCC 1

#include <iostream>
#include "xflens/cxxlapack/interface/interface.h"
#include "xflens/cxxlapack/netlib/netlib.h"

namespace cxxlapack {

template <typename IndexType>
IndexType
laed7(IndexType             icompq,
      IndexType             n,
      IndexType             qsiz,
      IndexType             tlvls,
      IndexType             curlvl,
      IndexType             curpbm,
      float                 *d,
      float                 *Q,
      IndexType             ldQ,
      IndexType             *indxq,
      float                 rho,
      IndexType             cutpnt,
      float                 *qstore,
      const IndexType       *qptr,
      const IndexType       *prmptr,
      const IndexType       *perm,
      const IndexType       *givptr,
      const IndexType       *givcol,
      const float           *givnum,
      float                 *work,
      IndexType             *iWork)
{
    CXXLAPACK_DEBUG_OUT("slaed7");

    IndexType info;
    LAPACK_IMPL(slaed7)(&icompq,
                        &n,
                        &qsiz,
                        &tlvls,
                        &curlvl,
                        &curpbm,
                        d,
                        Q,
                        &ldQ,
                        indxq,
                        rho,
                        &cutpnt,
                        qstore,
                        qptr,
                        prmptr,
                        perm,
                        givptr,
                        givcol,
                        givnum,
                        work,
                        iWork,
                        &info);
#   ifndef NDEBUG
    if (info<0) {
        std::cerr << "info = " << info << std::endl;
    }
#   endif
    ASSERT(info>=0);
    return info;
}


template <typename IndexType>
IndexType
laed7(IndexType             icompq,
      IndexType             n,
      IndexType             qsiz,
      IndexType             tlvls,
      IndexType             curlvl,
      IndexType             curpbm,
      double                *d,
      double                *Q,
      IndexType             ldQ,
      IndexType             *indxq,
      double                rho,
      IndexType             cutpnt,
      double                *qstore,
      const IndexType       *qptr,
      const IndexType       *prmptr,
      const IndexType       *perm,
      const IndexType       *givptr,
      const IndexType       *givcol,
      const double          *givnum,
      double                *work,
      IndexType             *iWork)
{
    CXXLAPACK_DEBUG_OUT("slaed7");

    IndexType info;
    LAPACK_IMPL(dlaed7)(&icompq,
                        &n,
                        &qsiz,
                        &tlvls,
                        &curlvl,
                        &curpbm,
                        d,
                        Q,
                        &ldQ,
                        indxq,
                        rho,
                        &cutpnt,
                        qstore,
                        qptr,
                        prmptr,
                        perm,
                        givptr,
                        givcol,
                        givnum,
                        work,
                        iWork,
                        &info);
#   ifndef NDEBUG
    if (info<0) {
        std::cerr << "info = " << info << std::endl;
    }
#   endif
    ASSERT(info>=0);
    return info;
}


template <typename IndexType>
IndexType
laed7(IndexType             icompq,
      IndexType             n,
      IndexType             qsiz,
      IndexType             tlvls,
      IndexType             curlvl,
      IndexType             curpbm,
      float                 *d,
      std::complex<float >  *Q,
      IndexType             ldQ,
      float                 rho,
      IndexType             *indxq,
      float                 *qstore,
      const IndexType       *qptr,
      const IndexType       *prmptr,
      const IndexType       *perm,
      const IndexType       *givptr,
      const IndexType       *givcol,
      const float           *givnum,
      std::complex<float >  *work,
      float                 *rWork,
      IndexType             *iWork)
{
    CXXLAPACK_DEBUG_OUT("claed7");

    IndexType info;
    LAPACK_IMPL(claed7)(&icompq,
                        &n,
                        &qsiz,
                        &tlvls,
                        &curlvl,
                        &curpbm,
                        d,
                        reinterpret_cast<float  *>(Q),
                        &ldQ,
                        rho,
                        indxq,
                        qstore,
                        qptr,
                        prmptr,
                        perm,
                        givptr,
                        givcol,
                        givnum,
                        reinterpret_cast<float  *>(work),
                        rWork,
                        iWork,
                        &info);
#   ifndef NDEBUG
    if (info<0) {
        std::cerr << "info = " << info << std::endl;
    }
#   endif
    ASSERT(info>=0);
    return info;
}

template <typename IndexType>
IndexType
laed7(IndexType             icompq,
      IndexType             n,
      IndexType             qsiz,
      IndexType             tlvls,
      IndexType             curlvl,
      IndexType             curpbm,
      double                *d,
      std::complex<double>  *Q,
      IndexType             ldQ,
      double                rho,
      IndexType             *indxq,
      double                *qstore,
      const IndexType       *qptr,
      const IndexType       *prmptr,
      const IndexType       *perm,
      const IndexType       *givptr,
      const IndexType       *givcol,
      const double          *givnum,
      std::complex<double>  *work,
      double                *rWork,
      IndexType             *iWork)
{
    CXXLAPACK_DEBUG_OUT("zlaed7");

    IndexType info;
    LAPACK_IMPL(zlaed7)(&icompq,
                        &n,
                        &qsiz,
                        &tlvls,
                        &curlvl,
                        &curpbm,
                        d,
                        reinterpret_cast<double *>(Q),
                        &ldQ,
                        rho,
                        indxq,
                        qstore,
                        qptr,
                        prmptr,
                        perm,
                        givptr,
                        givcol,
                        givnum,
                        reinterpret_cast<double *>(work),
                        rWork,
                        iWork,
                        &info);
#   ifndef NDEBUG
    if (info<0) {
        std::cerr << "info = " << info << std::endl;
    }
#   endif
    ASSERT(info>=0);
    return info;
}

} // namespace cxxlapack

#endif // CXXLAPACK_INTERFACE_LAED7_TCC
